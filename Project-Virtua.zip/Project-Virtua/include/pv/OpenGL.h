#include <GL/GL.h>
#include <GL/GLU.h>

#define GL_MAJOR_VERSION 0x821B
#define GL_MINOR_VERSION 0x821C